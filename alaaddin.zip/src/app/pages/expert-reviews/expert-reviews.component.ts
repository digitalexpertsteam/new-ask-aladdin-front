import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expert-reviews',
  templateUrl: './expert-reviews.component.html',
  styleUrls: ['./expert-reviews.component.css']
})
export class ExpertReviewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
