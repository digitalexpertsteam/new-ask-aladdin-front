import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-egypt-splendor',
  templateUrl: './egypt-splendor.component.html',
  styleUrls: ['./egypt-splendor.component.css']
})
export class EgyptSplendorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
