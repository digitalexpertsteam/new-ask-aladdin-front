import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-optional-experts',
  templateUrl: './optional-experts.component.html',
  styleUrls: ['./optional-experts.component.css']
})
export class OptionalExpertsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
