import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sponsors-logo',
  templateUrl: './sponsors-logo.component.html',
  styleUrls: ['./sponsors-logo.component.css']
})
export class SponsorsLogoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
