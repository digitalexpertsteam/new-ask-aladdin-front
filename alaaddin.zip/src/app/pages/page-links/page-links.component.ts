import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-links',
  templateUrl: './page-links.component.html',
  styleUrls: ['./page-links.component.css']
})
export class PageLinksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
