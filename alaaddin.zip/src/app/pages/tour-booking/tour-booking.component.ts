import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tour-booking',
  templateUrl: './tour-booking.component.html',
  styleUrls: ['./tour-booking.component.css']
})
export class TourBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
