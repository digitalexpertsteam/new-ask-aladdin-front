import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-city-guide',
  templateUrl: './city-guide.component.html',
  styleUrls: ['./city-guide.component.css']
})
export class CityGuideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
