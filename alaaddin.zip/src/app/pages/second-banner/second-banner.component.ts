import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second-banner',
  templateUrl: './second-banner.component.html',
  styleUrls: ['./second-banner.component.css']
})
export class SecondBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
