import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-guide',
  templateUrl: './site-guide.component.html',
  styleUrls: ['./site-guide.component.css']
})
export class SiteGuideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
