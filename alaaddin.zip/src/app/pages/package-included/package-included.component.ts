import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-package-included',
  templateUrl: './package-included.component.html',
  styleUrls: ['./package-included.component.css']
})
export class PackageIncludedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
