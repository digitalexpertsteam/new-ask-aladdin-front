import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starting-from',
  templateUrl: './starting-from.component.html',
  styleUrls: ['./starting-from.component.css']
})
export class StartingFromComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
