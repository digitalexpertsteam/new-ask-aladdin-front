import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prices-dates',
  templateUrl: './prices-dates.component.html',
  styleUrls: ['./prices-dates.component.css']
})
export class PricesDatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
