import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trav-exp',
  templateUrl: './trav-exp.component.html',
  styleUrls: ['./trav-exp.component.css']
})
export class TravExpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
