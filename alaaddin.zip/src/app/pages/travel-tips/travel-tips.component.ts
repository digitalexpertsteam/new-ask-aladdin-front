import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-tips',
  templateUrl: './travel-tips.component.html',
  styleUrls: ['./travel-tips.component.css']
})
export class TravelTipsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
