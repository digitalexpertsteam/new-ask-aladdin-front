import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hightlightes',
  templateUrl: './hightlightes.component.html',
  styleUrls: ['./hightlightes.component.css']
})
export class HightlightesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
