import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verfied-agent',
  templateUrl: './verfied-agent.component.html',
  styleUrls: ['./verfied-agent.component.css']
})
export class VerfiedAgentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
