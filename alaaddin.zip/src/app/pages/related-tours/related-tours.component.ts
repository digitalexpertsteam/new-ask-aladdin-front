import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-related-tours',
  templateUrl: './related-tours.component.html',
  styleUrls: ['./related-tours.component.css']
})
export class RelatedToursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
