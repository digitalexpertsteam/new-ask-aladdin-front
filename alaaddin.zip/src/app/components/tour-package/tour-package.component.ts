import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tour-package',
  templateUrl: './tour-package.component.html',
  styleUrls: ['./tour-package.component.css']
})
export class TourPackageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
 
  }

}
