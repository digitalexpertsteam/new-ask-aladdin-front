export interface Blog {
    id:number;
    name:string;
    slug:string;
    content:string;
    thumb_alt:string;
    thumb:string;
    created_at:string
  }