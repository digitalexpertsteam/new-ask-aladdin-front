export interface destination {
    id:number;
    name:string;
    slug:string;
    description:string;
    thumb_alt:string;
    thumb:string;
  }