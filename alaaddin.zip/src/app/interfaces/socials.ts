export interface socials {
    id:number;
    facebook:string;
    twitter:string;
    instagram:string;
    youtube:string;
    flickr:string;
    linkedin:string;
    pinterest: string;
    address1:string;
    address2:string;
    phone1:string;
    phone2:string;
    mail:string;
}