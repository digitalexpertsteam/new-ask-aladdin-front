export interface About {
    id:number;
    title:string;
    description:string;
    video:string;
  }