export interface sliders {
    id:number;
    title:string;
    alt:string;
    image:string;
    small_text:string;
  }