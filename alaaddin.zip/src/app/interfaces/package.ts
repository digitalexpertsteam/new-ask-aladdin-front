export interface packages {
    id:number;
    name:string;
    slug:string;
    description:string;
    thumb_alt:string;
    thumb:string;
    start_price:string;
    days: number
  }